const cookie = 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Atoken-exchange&latitude=0&longitude=0&platform=browser&subject_token=DISNEYASSERTION&subject_token_type=urn%3Abamtech%3Aparams%3Aoauth%3Atoken-type%3Adevice';
const assertion = '{"deviceFamily":"browser","applicationRuntime":"chrome","deviceProfile":"windows","attributes":{}}';
const authbear = 'Bearer ZGlzbmV5JmJyb3dzZXImMS4wLjA.Cu56AgSfBTDag5NiRA81oLHkDZfu5L3CKadnefEAY84';
const ua = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36';
const gql = '{"query":"mutation refreshToken($input: RefreshTokenInput!) {' +
    'refreshToken(refreshToken: $input) {' +
    'activeSession {' +
    'sessionId' +
    '}' +
    '}' +
    '}","variables":{"input":{"refreshToken":"ILOVEDISNEY"}}}';

const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_WAIT = '255,213,128';
const C_UNK = '92,207,230';

function handler() {
    const assertionToken = fetch('https://disney.api.edge.bamgrid.com/devices', {
        method: 'POST',
        headers: {
            'User-Agent': ua,
            'Authorization': authbear,
            'Content-Type': 'application/json',
        },
        body: assertion,
        noRedir: true,
        retry: 3,
        timeout: 5000,
    }) || {};

    const assertionTokenJson = safeParse(assertionToken.body) || {};
    const assertionCookie = cookie.replace('DISNEYASSERTION', assertionTokenJson.assertion || '');

    const token = fetch('https://disney.api.edge.bamgrid.com/token', {
        method: 'POST',
        headers: {
            'User-Agent': ua,
            'Authorization': authbear,
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: assertionCookie,
        noRedir: true,
        retry: 3,
        timeout: 5000,
    }) || {};

    const tokenJson = safeParse(token.body);
    if (tokenJson && tokenJson.error_description == 'forbidden-location') {
        return {
            text: '失败',
            background: C_FAIL,
        };
    } else if (!tokenJson) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (!tokenJson.refresh_token) {
        return {
            text: '查询失败',
            background: C_NA,
        };
    } else {
        const payload = gql.replace('ILOVEDISNEY', tokenJson.refresh_token);
        const content = fetch('https://disney.api.edge.bamgrid.com/graph/v1/device/graphql', {
            method: 'POST',
            headers: {
                'User-Agent': ua,
                'Authorization': authbear,
            },
            body: payload,
            noRedir: true,
            retry: 3,
            timeout: 5000,
        }) || {};
        const unavailable = ((fetch('https://disneyplus.com', {
            headers: {
                'User-Agent': ua,
            },
            noRedir: true,
            retry: 3,
            timeout: 5000,
        }) || {}).body || '').indexOf('unavailable') > -1;
        const contentData = safeParse(content.body) || {};
        const region = (get(contentData, 'extensions.sdk.session.location.countryCode') || '').toLocaleUpperCase();
        const inSupportedLocation = get(contentData, 'extensions.sdk.session.inSupportedLocation');

        if (region == 'JP') {
            return {
                text: '解锁(JP)',
                background: C_UNL,
            };
        } else if (region && !inSupportedLocation && !unavailable) {
            return {
                text: '待解锁(' + region + ')',
                background: C_WAIT,
            };
        } else if (region && unavailable) {
            return {
                text: '失败(' + region + ')',
                background: C_NA,
            };
        } else if (region && inSupportedLocation) {
            return {
                text: '解锁(' + region + ')',
                background: C_UNL,
            };
        } else {
            return {
                text: '未知',
                background: C_UNK,
            };
        }
    }
}