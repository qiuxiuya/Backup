function BeforeTask(taskType, slaveName, node, message, isAdmin) {
  println(`${isAdmin ? 'Admin' : 'User'} ${message.from.id} is invoking ${taskType} for ${node?.Name} on slave:${slaveName}`);

  // if (taskType.startsWith("/speed")) {
  //   return "❌ 当前机器人不允许 /speed 测试";
  // }

  return isAdmin;
}

function AfterTask(taskType, slaveName, node, message, isAdmin, slaveTask, outputImage) {
  println(`${isAdmin ? 'Admin' : 'User'} ${message.from.id} has invoked ${taskType} for ${node.Name} on slave:${slaveName}`);

  const speedList = get(slaveTask, "TaskResult.Speed") || [];
  const connList = get(slaveTask, "TaskResult.Conn") || [];
  const analyzeList = get(slaveTask, "TaskResult.Analyze");


  println(`Speed: ${speedList.length}, Conn: ${connList.length}, Analyze: ${!!analyzeList}`);
}