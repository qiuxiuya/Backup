const BASEURL = "https://api.ip.sb/geoip/";
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36';

function ip_resolve() {
	const endpoints = ["https://1.1.1.1/cdn-cgi/trace", "https://www.cloudflare.com/cdn-cgi/trace"];
	const ret = [];
	for (let i = 0; i < endpoints.length; i++) {
		const url = endpoints[i];
		const content = (get(fetch(url, {
			headers: {
				'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
			},
			retry: 1,
        	timeout: 1600,
		}), "body") || "").trim();

		const ip = (content.split('\n').filter(s => s.startsWith('ip='))[0] || 'ip=').substr(3);
		if (ip) ret.push(ip);
	}
	return ret;
}

// 支持 v4 + v6
function handler_ipsb(ip) {
    const content = fetch(BASEURL+ip, {
        headers: {
            'User-Agent': UA,
        },
    })
    return safeParse(get(content, "body"));
}

// 支持 v4 + v6
// 请升级到 3.2.1 再使用本脚本
function handler_bgptools(ip) {
    if (!ip) {
        const data = get(fetch("https://cloudflare.com/cdn-cgi/trace"), "body", "").split("\n").filter(s => s.startsWith("ip="));
        if (data.length) {
            ip = data[0].slice(3);
        }
    }
    const ret = netcat("bgp.tools:43", `begin\n${ip}\nend\n`);
    if (ret.error) {
        println("NetCat Error:", ret.error);
    }
    const data = get(ret, "data", "").split("|");
    const as = parseInt((data[0] || "").trim(), 10) || 0;
    const ipaddr = (data[1] || "").trim();
    const region = (data[3] || "").trim();
    const org = (data[6] || "").trim();
    return {
        "ip": ipaddr,
        "isp": org,
        "organization": org,
        "asn": as,
        "asn_organization": org,
        "region": region,
        "country": region,
        "country_code": region,
    }
}

// !!! 只支持 v4
function handler_ipinfo(ip) {
    const content = fetch("https://ipinfo.io/"+ip)
    const ret = safeParse(get(content, "body"));
    const asInfo = get(ret, "org", "").split(" ");
    const asn = asInfo.shift();
    const org = asInfo.join(" ");
    const loc = get(ret, "loc", "").split(",");

    return {
        "ip": get(ret, "ip", ""),
        "isp": org,
        "organization": org,
        "latitude": parseFloat(loc[0]),
        "longitude": parseFloat(loc[1]),
        "asn": parseInt(asn.replace("AS", ""), 10),
        "asn_organization": org,
        "timezone": get(ret, "timezone", ""),
        "region": get(ret, "region", ""),
        "city": get(ret, "city", ""),
        "country": get(ret, "country", ""),
        "country_code": get(ret, "country", ""),
        "hostname": get(ret, "hostname", ""),
    }
}

// 支持 v4 + v6
function handler_ipapi(ip) {
    const content = fetch(`http://ip-api.com/json/${ip}?lang=en-US`, {
        headers: {
            'User-Agent': UA,
        },
        retry: 3,
        timeout: 2000,
    });
    const ret = safeParse(get(content, "body"));
    const asInfo = get(ret, "as", "").split(" ");
    const asn = (asInfo.shift() || "").substr(2);
    const asnorg = asInfo.join(" ");

    return {
        "ip": get(ret, "query", ""),
        "isp": get(ret, "isp", ""),
        "organization": get(ret, "org", ""),
        "latitude": get(ret, "lat", 0),
        "longitude": get(ret, "lon", 0),
        "asn": parseInt(asn, 10) || 0,
        "asn_organization": asnorg,
        "timezone": get(ret, "timezone", ""),
        "region": get(ret, "region", ""),
        "city": get(ret, "city", ""),
        "country": get(ret, "country", ""),
        "country_code": get(ret, "countryCode", ""),
    }
}

const handler = handler_ipapi;
