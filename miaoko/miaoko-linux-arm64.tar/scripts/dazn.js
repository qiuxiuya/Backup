const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';
const C_WAIT = '255,213,128';

function handler() {
    const content = fetch('https://startup.core.indazn.com/misl/v5/Startup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: '{"LandingPageKey": "generic", "Languages": "zh-TW,zh,en-US,en", "Platform": "web", "Version": "2" }',
        noRedir: true,
        retry: 3,
        timeout: 5000,
    }) || {};


    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.statusCode == 200) {
        let res = JSON.parse(content.body)
        if (res.Region.isAllowed) {
            return {
                text: '解锁('+ res.Region.Country.toUpperCase() + ')',
                background: C_UNL,
            };
        } else if(!res.Region.isAllowed){
            return {
                text: '待解锁',
                background: C_WAIT,
            };
        }else {
            return {
                text: '失败',
                background: C_FAIL,
            };
        }
    } else {
        return {
            text: '失败',
            background: C_FAIL,
        };
    }
}
