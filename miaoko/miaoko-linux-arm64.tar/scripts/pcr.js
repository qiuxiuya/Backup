function handler() {
  const content = fetch("https://api-priconne-redive.cygames.jp", {
    headers: {
      "User-Agent":
        "Dalvik/2.1.0 (Linux; U; Android 9; ALP-AL00 Build/HUAWEIALP-AL00)",
    },
    noRedir: false,
    retry: 3,
    timeout: 2500,
  });

  if (!content) {
    return {
      text: 'N/A',
      background: '142,140,142',
    };
  } else if (content.statusCode == 404) {
    return {
      text: '解锁',
      background: '186,230,126',
    };
  } else if (content.statusCode == 403) {
    return {
      text: '失败',
      background: '239,107,115',
    };
  } else {
    return {
      text: '未知',
      background: '92,207,230',
    };
  }
}