const cookies1 = 'grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Atoken-exchange&latitude=0&longitude=0&platform=browser&subject_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJjYWJmMDNkMi0xMmEyLTQ0YjYtODJjOS1lOWJkZGNhMzYwNjkiLCJhdWQiOiJ1cm46YmFtdGVjaDpzZXJ2aWNlOnRva2VuIiwibmJmIjoxNjMyMjMwMTY4LCJpc3MiOiJ1cm46YmFtdGVjaDpzZXJ2aWNlOmRldmljZSIsImV4cCI6MjQ5NjIzMDE2OCwiaWF0IjoxNjMyMjMwMTY4LCJqdGkiOiJhYTI0ZWI5Yi1kNWM4LTQ5ODctYWI4ZS1jMDdhMWVhMDgxNzAifQ.8RQ-44KqmctKgdXdQ7E1DmmWYq0gIZsQw3vRL8RvCtrM_hSEHa-CkTGIFpSLpJw8sMlmTUp5ZGwvhghX-4HXfg&subject_token_type=urn%3Abamtech%3Aparams%3Aoauth%3Atoken-type%3Adevice';
const auth1 = 'Bearer ZXNwbiZicm93c2VyJjEuMC4w.ptUt7QxsteaRruuPmGZFaJByOoqKvDP2a5YkInHrc7c';
const auth2 = 'ZXNwbiZicm93c2VyJjEuMC4w.ptUt7QxsteaRruuPmGZFaJByOoqKvDP2a5YkInHrc7c';
const ua = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36';
const content1 = '{"query":"mutation registerDevice($input: RegisterDeviceInput!) {\n            registerDevice(registerDevice: $input) {\n                grant {\n                    grantType\n                    assertion\n                }\n            }\n        }","variables":{"input":{"deviceFamily":"browser","applicationRuntime":"chrome","deviceProfile":"windows","deviceLanguage":"zh-CN","attributes":{"osDeviceIds":[],"manufacturer":"microsoft","model":null,"operatingSystem":"windows","operatingSystemVersion":"10.0","browserName":"chrome","browserVersion":"96.0.4664"}}}}';

const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_WAIT = '255,213,128';
const C_UNK = '92,207,230';

function handler() {
    
    const token = fetch('https://espn.api.edge.bamgrid.com/token', {
        method: 'POST',
        headers: {
            'User-Agent': ua,
            'Authorization': auth1,
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: cookies1,
        noRedir: true,
        retry: 5,
        timeout: 5000,
    }) || {};

    const tokenJson = safeParse(token.body);
    if (tokenJson && tokenJson.error_description == 'forbidden-location') {
        return {
            text: '不支持',
            background: C_FAIL,
        };
    } else if (!tokenJson) {
        return {
		  text: '不支持',
            background: C_FAIL,
        };
    } else if (!tokenJson.refresh_token) {
        return {
		  text: '不支持',
            background: C_FAIL,
        };
    } else {
        const result = fetch('https://espn.api.edge.bamgrid.com/graph/v1/device/graphql', {
            method: 'POST',
            headers: {
                'User-Agent': ua,
                'Authorization': auth2,
            },
            body: content1,
            noRedir: true,
            retry: 3,
            timeout: 5000,
        }) || {};
        const resultJson = safeParse(result.body) || {};
             const region = (get(resultJson, 'extensions.sdk.session.location.countryCode') || '').toLocaleUpperCase();
        const inSupportedLocation = get(resultJson, 'extensions.sdk.session.inSupportedLocation');

        if (inSupportedLocation && region == 'US'){
            return {
                text: '解锁',
                background: C_UNL,
            };
    }else {
            return {
                text: '不解锁',
                background: C_FAIL,
        };
        }
    }
}