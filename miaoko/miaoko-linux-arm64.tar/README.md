# MiaoKo

MiaoKo 是一个自动化测试节点连通性的机器人，并会自动生成连通报告以方便使用者运维。

> 使用前须知：从 3.0.0 开始，miaoko 被分为主端 (MiaoKo) 和后端 (MiaoSpeed)。

## 前言

其中，主端可以放在任何地方，它主要负责接受 Telegram / WebAPI (未上线) 指令、解析订阅链接、负载均衡、任务分发，最后整合信息、生成图片、调用 WebHook。它不直接参与任何与节点的信息交流。后端则需要部署在模拟真实的环境中（例如，如果你希望测试得到的结果与普通家庭用户的体感类似，则你需要把后端部署在家宽后）。

一般来说典型的 MiaoKo 部署方式为：主端部署在国外，例如香港、日本等地。后端部署在国内（具有固定 IP 的商宽部署方式会容易很多，如果是动态且在 NAT 后的家宽，则需要自建 FRP，这里就不多赘述了）。

### 后端数量

如果您的授权是 Minor，您只可以添加 1 个后端，而 Major 您将可以最多添加 3 个后端，Ultimate 则是无限制。

### 关于后端共享

主端的配置中，你需要绑定你的 Telegram Bot Token，以及 MiaoKo 授权码，因此你只能拥有一个主端，而后端则不需要。MiaoKo 后端是一个无状态的服务器。这意味着你可以和你的好友共享一个后端（后端测速任务采用 Round Robin 的方法，在同一时间只会有一个测速任务运行以保证结果尽可能准确。因此如果有过多的人共享一个后端并频繁使用 Speed 你会发现任务的速度会明显变慢。其他指令则没有这个影响）。

## 关于数据安全

MiaoKo 处理的所有的数据都不会以任何方式保存：包括但不限于 Telegram 消息、stdout 系统日志、错误上报。

MiaoKo 会在 config.yaml 文件中存储订阅信息(但仅限于使用 /new 添加的订阅，并不适用于 /*url 系列的临时测试)。

MiaoKo 不会记录任何 IP、地理位置、流量、测试访问记录等数据。

MiaoKo 会主动或被动连接的服务器为 sentry.io (脱敏错误上报)、MiaoSpeed、subconverter（如果你配置了）、订阅服务器、（或者连接你自己脚本里用 fetch 执行的服务器）。除此之外它不会与任何其他的服务器发送任何形式的通讯（你可以抓包看看 :)）。

MiaoSpeed 不储存任何日志、且只会与 MiaoKo 和 节点服务器发生数据交换。

## 机器人安装方法

### 简述

对于 Major | Ultimate 的用户，你们可以使用一键脚本：它的下载地址在 $DOMAIN/wizard/setup.sh。其中 $DOMAIN 为你在授权控制台看到的下载域名。

由于机器人的配置比较复杂。你们可以参考下章节 [#机器人配置说明](#机器人配置说明) 或者 readme.config.yaml 文件，以查阅各个配置的详细说明。

### 手动下载

MiaoKo 采用 tar.gz 的压缩/打包方式。你只需要在下载中找到对应的版本即可下载程序：miaoko-A-B.tgz 以及 miaospeed-A-B.tgz。

其中 A 代表操作系统，darwin 是苹果 Macintosh 系统，linux 和 windows 就不必说了。B 代表系统架构，amd64 代表是 64 位 x86 处理器架构，而 arm64 代表是 64 位 arm 处理器架构。MiaoKo 暂不支持其他架构。如果您希望 MiaoSpeed 有其他架构的打包（例如 armv7，请来群里与我详谈）。

linux 和 mac 可以用 `tar zxf 文件名.tgz` 的方法来解压缩文件，而 windows 你则需要自信下载软件，这里也没法推荐 lol。

### 机器人配置说明

> 关于如何让 miaoko 与 miaospeed 持久化运行这里不会详细说，你可以参考 `screen`, `pm2`, `systemd` 等方法，如果是一键脚本安装的主端，它采用 `systemd` 的方式持久化运行。

这里我将详细讲述机器人的几个部分：

- 必要配置
- 后端相关
- 权限相关
- 机器人相关
- 任务相关

### 必要配置

这些配置你必须设置，否则你的机器人很可能无法启动：

- `$CONFIG.superKeepers` [#权限相关](#权限相关)
- `$CONFIG.slaveConfig` [#后端配置](#后端配置)
- `$CONFIG.output`: 一些图片生成时的配置，可以借鉴 *readme.config.yaml*
- `$CONFIG.token`: 你的 MiaoKo 授权码
- `$CONFIG.telegramToken` 你的 Telegram Bot 认证码（@BotFather 会给你，类似 123456:rogijaowrijfoawie 这样的一串）

其他配置大多都为可选，不影响基础功能运行。关于最简配置可以参考 *example.config.yaml* （不过请务必修改 `superKeepers`, `slaveConfig`, `token` 和 `telegramToken`）

#### Webhook 模式

如果您想使用 Telegram 的 Webhook 模式，您需要在启动时增加 `-webhook https://your.domain:port -nosetwebhook` 的设置。需要注意的是，你的 `port` 必须满足 Telegram 的端口要求，否则会设置无效：https://core.telegram.org/bots/api#setwebhook

#### 后端相关

##### 后端搭建 (4.0.0+)

您可以在 https://github.com/miaokobot/miaospeed 获取开源版 MiaoSpeed。

在下载并得到 `miaospeed` 可执行文件以后，你可以运行如下命令快速设置完毕：

```bash
./miaospeed server -bind 0.0.0.0:9876 -token miaokomiaokoyyds
```

这意思是，监听 `0.0.0.0` IP 上的 `9876` 端口，并设置后端密码 `miaokomiaokoyyds`。如果后端收到非法的请求（即没有用 `miaokomiaokoyyds` 串签名）则统统不会受理。

如果你的主端和后端在同一台服务器上（虽然极不推荐），你还可以用 Linux 套接字的方法监听一个文件 socket：

```bash
./miaospeed server -bind /tmp/miaoko.unix -token miaokomiaokoyyds
```

##### 加密传输

自 `3.6.0` 版本后，后端支持 tls，您可以使用 miaoko 自签证书保证只有主端与后端通信。当然您也可以使用自己的证书，并为 miaospeed 套上 nginx / caddy 等前置。自签名证书使用方法:

```bash
./miaospeed server -bind 0.0.0.0:9876 -mtls -token miaokomiaokoyyds
```

此时您需要在 `config.yaml` 中配置 `address: mwss://some.address.com:9876` (而非 wss://) 来完成 miaoko 根证书校验。

##### 禁止用于测速

你可以加上 `-nospeed` 参数防止此后端用于测速，例如:

```bash
./miaospeed server -bind 0.0.0.0:9876 -token miaokomiaokoyyds -nospeed
```

##### 白名单

如果您希望你的后端只和某一个主端通信，自 `3.9.0` 版本开始，您可以新增 `-whitelist <BotId1,BotId2,...>` 参数的方式来限制制定机器人主端使用，例如：

```bash
./miaospeed -b 0.0.0.0:9876 -whitelist 185829314,285810293
```

虽然 `-whitelist` 可以和 `-token` 共同使用，但既然您已经指定了白名单，再设置密码就有些多此一举了。

##### 其他

除了启动后端外，MiaoSpeed 可以单独测试流媒体脚本，但是无法生成图片。您可以运行以下指令查看：

```bash
./miaospeed script -help
```

至此，MiaoSpeed 已经配置结束，之后的配置都在 MiaoKo 完成。

##### 后端配置

配置文件（slaves 为一个字典，其中 `guangzhou` `shanghai` 都为 **后端ID**，可以自定义，但只限英文）：
```yaml
slaveConfig:
  default: guangzhou
  slaves:
    guangzhou:
      address: ws://public.miao.re:12345
      token: p123412341234
    shanghai:
      address: ws://public2.miao.re:12345
```

这里意思是，配置了两个喵速后端，一个叫 `guangzhou` 它的密码是 `p123412341234`。另一个 `shanghai` 它没有密码。默认都是用 `guangzhou` 来进行测试。

#### 环境变量

4.0.0 以后，miaoko 支持通过环境变量的方法设置一些额外的值：

##### MIAOKO_SOCKS5_PROXY

通过设置这个环境变量，您可以让所有主端的三方请求（连接 miaospeed 的 websocket 与 请求订阅的连接）经由一个 SOCKS5 代理，例如：

```bash
export MIAOKO_SOCKS5_PROXY=127.0.0.1:7890
```

##### MIAOKO_TELEGRAM_SOCKS5_PROXY

通过设置这个环境变量，您可以让所有主端的 Telegram 请求经由一个 SOCKS5 代理，例如：

```bash
export MIAOKO_TELEGRAM_SOCKS5_PROXY=127.0.0.1:7890
```

#### 权限相关

Minor 和 Major 授权提供 1 个超级管理，Ultimate 提供无限个超级管理。

Minor 提供 0 个普通管理，Major 提供 8 个普通管理，Ultimate 提供无限个普通管理。

只有 Ultimate 可以使用权限相关回调。

##### 超级管理

超级管理是 MiaoKo 中最大的管理层级，它有最大的操作权限。这意味着，有超管可以随意读取、写入任何 config.yaml 中的配置（包括订阅信息）。超管可以使用 `/grant` 指令授权一个 Telegram 用户为普通管理。（`/ungrant` 来解除授权）

配置文件（数组，如果只有一个也必须有 `- ` 注意空格）：
```yaml
superKeepers:
- 11111
- 22222
```

##### 普通管理

普通管理可以操作的执行权，但是无法读取、改写配置信息。这意味着他们可以执行 `/speed` (`/speedx`) `/test` `/analyze` `/invite` 这些指令，但是无法使用 `/new` `/remove` `/list` `/prune` `/cron` 这些使用后会展示配置或者导致配置被修改的。

配置文件（数组，如果只有一个也必须有 `- ` 注意空格）：
```yaml
keepers:
- 11111
- 22222
```

##### 普通用户

普通用户只能读取管理员执行以后的结果，例如 `/report` 家族指令和 `/stats` 指令。这些指令不会执行任何新的测试，只会读取历史测试结果以给出反馈信息。

##### Ultimate 的权限回调 (4.0.0+)

对于 Ultimate 用户，可以设置 `$CONFIG.permissionCallbackURL` 为你的 API 后端。在每次用户触发测试指令时，miaoko 都会把请求转发至当前 url 来判断是否允许执行。如果返回 200 则开始执行，如果返回 400 或以上的错误代码，则展示返回内容作为错误回复。

#### 机器人相关

可以直接参考 *readme.config.yaml*

这里给一些简单的举例:

- `$CONFIG.subconverter`: 设置一个 SubConverter 后端
- `$CONFIG.relayBotMessagesUrl`: 把机器人无法处理的信息发给另外一个机器人（Ultimate 专用）
- `$CONFIG.threading`: 【废弃】默认测试线程数
- `$CONFIG.minCronInterval`: 最小允许的自动测试间隔
- `$CONFIG.maxKeepHistory`: 最大允许的历史存放条数
- `$CONFIG.keeperOnlyMode`: 只允许管理员调用指令（不允许普通用户使用任何指令）
- `$CONFIG.doNotShowMiaokoAds`: 不在 `/help` 里展示 @MiaoGroup 的广告（Ultimate 专用）
- `$CONFIG.allowKeeperToInviteToCreate`: 允许普通管理员邀请别人添加订阅

#### 任务相关

详细的配置请参考 *readme.config.yaml*

- `$CONFIG.nodes`: 订阅列表。一般不需要手动去写，可以直接用 `/new` 指令添加节点。
- `$CONFIG.scripts`: 脚本配置（流媒体或其他脚本），是一个字典，键代表展示在图表最上方的测试名称（例如 Netflix），值代表一段代码，或者一个 js 文件相对运行目录的位置（务必参考 *readme.config.yaml*）。对于 Major | Ultimate 用户，你们被免费赠送了 Netflix / Youtube Premium / Disney+ 的测试脚本。可以在 $DOMAIN/scripts/ 获取。
- `$CONFIG.commands`: 自定义指令。您可以通过这个定义您自己的测试内容，具体请参考 [#自定义指令](#自定义指令) 章节。

## 机器人使用方法

这里我会对机器人在 Telegram 中使用的方法进行说明：

> 你也可以直接对机器人发送 /help 指令来查看你能执行的指令（不同权限的用户获得的指令列表会有所差异）

### 公共指令

这里的指令所有人都能调用：（除非 `$CONFIG.keeperOnlyMode` 被开启）

#### /help

获取帮助菜单

#### /id

回复一个用户来查询 TA 的 Telegram 用户信息，包括 id、数据中心、语言信息等等

#### /version

查询机器人版本信息和编译序列号

#### /reportall <订阅ID>

获取某个订阅的在线/掉线节点列表。

⚠️ 注意：请先对订阅设置计划任务(`/cron`)后再使用该指令，因为它会获取最近一次测试的结果。如果不设置计划任务，则 `/reportall` 的结果将没有参考价值（因为它你上次测试它很可能在几天甚至几个月以前）。

#### /reportonline <订阅ID>

同上，只是它只会返回在线的节点

#### /reportoffline <订阅ID>

同上，只是它只会返回掉线的节点

#### /stats <订阅ID>

它与 `/reportall` 类似，但是，它不止返回最近一次的测试结果，而是会生成一个节点稳定性的折线图。（它会读取[默认]近 120 此的测试数据并绘制图表，因此，如果没有设置计划任务(`/cron`)，该指令不会被允许调用。）

如果想改变 120 这个值，请参考 `$CONFIG.maxKeepHistory`。如果不想改变它，请设置 `$CONFIG.nodes.<订阅ID>.stats` 为 `true`。

### 计划任务类指令

计划任务指令只能由管理、超级管理调用。

#### /cron <订阅ID> <Cron表达式?>

为某个订阅设置计划任务，例如：每2分钟测试一次 mycloud 并写入历史记录：

```
/cron mycloud @every 2m
```

你也可以不加表达式来查询某个订阅的计划任务配置：

```
/cron mycloud

返回:
✔ 当前配置: @every 2m
下次执行: 2022-03-20T23:57:32Z
...
```

#### /register <订阅ID> <私密等级?>

既然设置了计划任务，当节点掉线/恢复时，MiaoKo 就能提醒你。在需要 MiaoKo 提醒的群发送这个指令就能设置掉线提醒。但如果这个群是公开群，你不想泄露掉线提醒中的 ip / 域名信息，就可以单独配置私密等级。默认的等级是 0，意味着隐藏 2 级域名："www.\*.com"。如果没有你设置了 1，则会显示： "\*.\*.com" 以此类推。如果你设置了 -1，则会取消私密展示："www.mycloud.com"。

#### /registered

查询当前群注册的所有消息提示

#### /notify <订阅ID>

与 `/registered` 类似，但是从另一个纬度：这条指令查询的是某个订阅在哪些群被订阅了。

#### /unregister <订阅ID> <群组ID?>

取消一个群中某个订阅的掉线提醒。如果不加群组 ID，则会取消当前群的掉线提醒。

#### /mute <订阅ID> <持续时间(秒)>

如果你正在调试节点，导致节点频繁掉线，掉线提醒炸群。但你又不想 `/unregister` 所有关联的群。你可以用 `/mute` 把某个订阅的掉线提醒暂时关闭（但需要注意的是，`/cron` 并没有被暂停，它的掉线历史依然会被记录）。

### 自定义指令

> 要求 miaoko 4.0.0+ 版本

同样是管理员指令，他们是 MiaoKo 的核心功能。

#### 指令集

对于所有自定义指令，他们可以将一系列 miaospeed Matrix 打包后传输给后端进行测试。 miaoko 支持所有 miaospeed 的指令，您可以参考：

https://github.com/miaokobot/miaospeed/blob/fd7abecc2d36a0f18b08f048f9a53b7c0a26bd9e/interfaces/matrix.go#L6

中所罗列的指令。

#### 指令参数

在调用这些自定义指令时，您还可以添加如下参数：

**<正则表达式>**: 指 Regular Expression，是编程中常用的字符串查询方法。例如：`香港|日本` 代表所有包含香港或者日本的节点。由于 MiaoKo 的所有输入不识别空格，你可以通过这种方式过滤带有空格的节点：`美国\s0[0-6]` 代表 `美国 01` - `美国 06`。

**</cmd:A=B>**: 这是 MiaoKo 特有的附加参数。可以拓展这次测试的信息。例如，你想用在后端ID为 `guangzhou` 的机器上运行美国节点的测速，你可以这样写：

```
/speed:slave=guangzhou mycloud 美国
```

⚠️ 注意，**:A=B** 指令一定是紧贴着命令的（不能有空格）。

所有金刚都支持 **:A=B** 指令，目前支持的指令为：

- :slave=<后端ID> 指定后端进行测试
- :slavegroup=<后端组别ID> 指定后端组进行负载均衡测试
- :slavejoint=<后端组别ID> 指定后端组进行多后端联测
- :sort=name|ping|avgspeed|maxspeed|original

#### 指令派生

自定义指令中，所有指令又能增加 (/xxx)url 与 (/xxx)x 的后缀。前者表示临时测试，而后者代表实时测试（需要注意，实时测试必须在 Matrix 中携带 测速(SPEED) 相关指令才会被允许）

例如: 
- /ping 的派生指令为 /pingurl (由于系统自带的 ping 并不包含测速，因此不能使用 /pingx)
- /test 的派生指令为 /testurl
- /speed 的派生指令为 /speedurl 和 /speedx
- /analyze 的派生指令为 /analyze

#### 不可复写自带指令

系统自带4个自定义指令，其中，这两个不能被复写：

- /ping 联通性测试，自带的 Matrix 为 `[TEST_PING_RTT, TEST_PING_CONN]`
- /analyze 出入口结构分析，自带的 Matrix 为 `[GEOIP_INBOUND, GEOIP_OUTBOUND]`

#### 可复写自带指令

另外两个指令是可以被覆盖的，您可以创建 `$CONFIG.commands` 来进行覆盖：

- /test 流媒体测试，自带的 Matrix 为 `[TEST_PING_RTT, TEST_PING_CONN, TEST_SCRIPT]`
- /speed 速度测试，自带的 Matrix 为 `[TEST_PING_CONN, SPEED_AVERAGE, SPEED_MAX, SPEED_PER_SECOND]`

例如，如果您不喜欢 `/speed` 定义的方式，您只想要展示平均速度和每秒速度就够了，您可以添加:

```yaml
commands:
  speed: # 您要新增 / 覆盖的指令
    info: 更简单的测速
    emoji: 🚀
    matrixTypes:
      - SPEED_AVERAGE
      - SPEED_PER_SECOND
    realtime: true # 选填, 默认 false, 是否支持 /speedx 实时指令 (但注意，只有在 matrixTypes 里包含了测速类指令才能使用，否则会返回错误)
    disabled: false # 选填, 默认 false, 是否禁用指令 (只有超管能使用)
    allowNormalUsers: false # 选填, 默认 false, 是否允许所有人使用
```

另外，除了通过 `TEST_SCRIPT` 测试所有流媒体，您还可以使用 `TEST_SCRIPT::<script_id>` 的方式制定测试一个流媒体。

例如，您定义了:

```yaml
scripts:
  Netflix:
    ....
  Youtube:
    ....
  Disney:
    ....
```

您可以创建:

```yaml
commands:
  mystreaming:
    info: 测试奈飞和油管的解锁
    emoji: 📺
    matrixTypes:
      - TEST_SCRIPT::Netflix
      - TEST_SCRIPT::Youtube
```

#### /invite<:A=B>

回复一个用户来邀请他进行一次 `/testurl` `/speedurl` 或 `/analyzeurl`。如果邀请人是超级管理，则还可以邀请对方 `/new`。所有交互过程都在私聊中，因此不用担心订阅外泄。

### 订阅相关指令

这些指令都是超级管理的指令

#### /ignore <订阅ID> <正则表达式?>

忽略某个订阅中指定节点的连通性测试，例如：

```
/ignore mycloud 流量|官网
```

这样，所有节点名称包含 "流量" "官网" 字样的节点都不会参与 自定义指令 的任务流程，被排除在外。

如果你不传任何表达式，则默认表示列出所有表达式，来方便你 `/unignore`。

#### /unignore <订阅ID> <正则表达式>

同理，你可以恢复被你忽略的表达式。

#### /new <订阅ID> <订阅链接>

通过这种方式来新增订阅到订阅列表（自动写入 `$CONFIG.nodes`）

```
/new mycloud https://mycloud.com/clash/ewerioweoi3
```

#### /remove <订阅ID>

同样，你也可以删除某个订阅，例如：

```
/remove mycloud
```

#### /list

列出所有写在 `config.yaml` 文件中的 **订阅ID**

#### /prune

扫描所有在 `config.yaml` 文件中的订阅。把那些联不通的（过期的）订阅找出来。

### 系统相关指令

这些指令都是超级管理的指令

#### /grant

回复一个用户把 TA 变成管理员，会被写入到 `$CONFIG.keepers`。

#### /ungrant

回复一个用户把 TA 取消管理员，会被从 `$CONFIG.keepers` 移除。

私聊机器人发送 `/ungrant` 时会展示对话框，方便可视化批量处理。

#### /grantscan

对于旧版本，config.yaml 中并没有记录管理员显示名信息，可以使用这个命令进行批量补全。

### 调试指令

这些也是超级管理的指令，用于高手调试用，不适合新手。所以这里暂时不详细讲解。有兴趣的请群里一起讨论哦～

#### /get <反射路径>

对 `$CONFIG` 对象进行反射读取。你需要对 `config.yaml` 配置文件非常熟悉。例如，你想获取 `$CONFIG.subconverter` 的值：

```
/get SubConverter
返回：
✔️ 读取成功啦 ~
键: SubConverter
值: https://some.thing/sub
```

例如，你想获取 mycloud 这个订阅的地址：
```
/get Nodes.mycloud.URL
返回：
✔️ 读取成功啦 ~
键: Nodes.mycloud.URL
值: https://mycloud.com/clash/ewerioweoi3
```

再例如，获取默认的后端名字：
```
/get SlaveConfig.Default
返回：
✔️ 读取成功啦 ~
键: SlaveConfig.Default
值: guangzhou
```

在熟记 `config.yaml` 的同时，你需要把键第一个字母大写，就可以拼接上面的反射路径了（切记，如果键是你自定义的值，则不需要大写，例如**订阅ID**）
#### /set <反射路径> <值>

同上，只是这次我们设置这个值。

#### /logs <从?> <长度?>

获取系统日志，例如，打出最近 10 条系统日志:

```
/logs 0 10
```
