const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

ip_list = [
    'ssh://203.86.238.16:22', // HK Layerstack
    //'ssh://172.245.126.135:22', // US RackNerd
    //'ssh://38.150.14.220:22', // HK Hytron
    'ssh://61.147.96.219:22', // CN CT
]

function get_requests(ip) {
    const content = netcat(ip, '\r\n', {
        retry: 5,
        timeout: 10000,
    });
    if (content.data.indexOf('SSH') != -1) {
        return true
    }
    return false
}

function handler() {
    const temp_content = fetch('https://www.gstatic.com/generate_204', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!temp_content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    for (const ip of ip_list) {
        if (get_requests(ip) == true) {
            return {
                text: '解锁',
                background: C_UNL,
            };
        }
    }
    return {
        text: '失败',
        background: C_FAIL,
    };
}
