const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

const url =
  'https://zh.m.wikipedia.org/w/api.php?action=query&format=json&formatversion=2&prop=revisions%7Cinfo&rvprop=content%7Ctimestamp&titles=%E8%8D%94%E6%9E%9D&intestactions=edit&intestactionsdetail=full&rvsection=0';

function handler() {
  const content = fetch(url, {
    headers: {
      'User-Agent':
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
    },
    noRedir: false,
    retry: 3,
    timeout: 5000,
  });

  if (!content) {
    return {
      text: 'N/A',
      background: C_NA,
    };
  } else if (content.statusCode == 200) {
    let res = JSON.parse(content.body);

    const query = res.query;

    if (query.pages) {
      const edit = query.pages[0].actions.edit;
      if (edit[0] && edit[0].code === 'blocked') {
        return {
          text: '禁止编辑',
          background: C_FAIL,
        };
      } else {
        return {
          text: '允许编辑',
          background: C_UNL,
        };
      }
    } else {
      return {
        text: '失败',
        background: C_FAIL,
      };
    }
  } else {
    return {
      text: '未知',
      background: C_UNK,
    };
  }
}
