const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://ipinfo.io/widget/', {
        headers: {
            'User-Agent': 'curl/8.8.0',
            'Accept': '*/*'
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    let content_text = '';
    const ret = safeParse(get(content, "body"));
    const asn_type = get(get(ret, "asn", {}), "type", "");
    const company_type = get(get(ret, "company", {}), "type", "");
    const privacy_data = get(ret, "privacy", {});
    const is_proxy = get(privacy_data, "proxy", false);
    const is_relay = get(privacy_data, "relay", false);
    const is_tor = get(privacy_data, "tor", false);
    const is_vpn = get(privacy_data, "vpn", false);
    if (asn_type == "isp" && company_type == "isp") {
        content_text = '家宽'
    } else if (asn_type == "business" && company_type == "business") {
        content_text = '商宽'
    } else if (asn_type == "hosting" && company_type == "hosting") {
        content_text = '机房'
    } else {
        content_text = '商宽/机房'
    }
    if (is_proxy == true) {
        content_text = content_text + '代理'
    }
    if (is_relay == true) {
        content_text = content_text + '中继'
    }
    if (is_tor == true) {
        content_text = content_text + 'Tor'
    }
    if (is_vpn == true) {
        content_text = content_text + 'VPN'
    }
    return {
        text: content_text
    }
}
