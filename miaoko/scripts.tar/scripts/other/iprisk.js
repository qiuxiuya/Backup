/*
 # @Author: Telegram @FullTclash
 # @Date: 2023-03-06
 # @Telegram: https://t.me/FullTclash
 # Copyright © 2023 by FullTclash, All Rights Reserved. 
 # 允许重写、转载、重新分发此脚本乃至商用。要求保留此原作者信息。
*/
const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';


function handler() {
  const ipcontent = fetch('http://ip-api.com/json', {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
    },
    noRedir: false,
    retry: 3,
    timeout: 5000,
  });
  const baseurl = "https://scamalytics.com/ip/"
  if (!ipcontent) {
    return {
      text: 'N/A',
      background: C_NA,
    };
  } else if (ipcontent.statusCode == 200) {
    const ipContentData = JSON.parse(ipcontent.body)
    ip = ipContentData.query
    url = baseurl+ ip;
    if (!ip){
        return {
            text: 'N/A',
            background: C_NA,
          };
    }else{
        const content = fetch(url, {
            headers: {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
            },
            noRedir: false,
            retry: 3,
            timeout: 5000,
        });
        if (!content) {
            return {
              text: 'N/A',
              background: C_NA,
            };
        } else if (content.statusCode == 200){
            let index = content.body.indexOf('IP Fraud Risk API');
            let info_pre = index > 0 ? content.body.slice(index + 96, index + 180) : "{}";
            let index2 = info_pre.indexOf("}");
            let info_str2 = index2 > 0 ? info_pre.slice(0, index2 + 1) : "{}";
            let info = JSON.parse(info_str2);
            let score = info.score || '无';
            let risk = (info.risk || '无').toUpperCase();
            return {
                text: risk+'('+score+')',
                background: '255,255,255',
            };
        }else{
            return {
                text: 'N/A',
                background: C_NA,
            };
        }
    }
  } else{
        return {
            text: 'N/A',
            background: C_NA,
    };
  }
}
