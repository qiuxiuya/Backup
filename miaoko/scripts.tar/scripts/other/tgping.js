const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function get_requests(ip) {
    var ts = Date.now()
    const content = fetch(`http://${ip}:80`, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return 2147483647
    }
    return Date.now() - ts
}

function handler() {
    const temp_content = fetch('https://www.youtube.com/', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!temp_content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    content_text = 'N/A'
    min_time = 2147483647
    var ts = get_requests('91.108.56.130');
    if (min_time > ts) {
        content_text = 'DC5'
        min_time = ts
    }
    ts = get_requests('149.154.167.91');
    if (min_time > ts) {
        content_text = 'DC4'
        min_time = ts
    }
    ts = get_requests('149.154.167.51');
    if (min_time > ts) {
        content_text = 'DC2'
        min_time = ts
    }
    ts = get_requests('149.154.175.53');
    if (min_time > ts) {
        content_text = 'DC1'
        min_time = ts
    }
    //ts = get_requests('149.154.175.100');
    //if (min_time > ts) {
    //    content_text = 'DC3'
    //    min_time = ts
    //}
    if (min_time == 2147483647) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    return {
        text: content_text + '(' + String(min_time) + 'ms)'
    }
}