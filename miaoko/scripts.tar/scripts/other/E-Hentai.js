const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';
const C_CN = '250,213,149';

function handler() {
    const content = fetch('https://exhentai.org/', {
        headers: {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            //'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'max-age=0',
            'Cookie': 'ipb_member_id=4520928; ipb_pass_hash=925cc4de040051f7024333fb45f63a2a; yay=louder; igneous=5c521e916',
            'Priority': 'u=0, i',
            'Sec-Ch-Ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
            'Sec-Ch-Ua-Mobile': '?0',
            'Sec-Ch-Ua-Platform': '"Windows"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
            
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.body.indexOf('has been temporarily banned') == -1) {
        if (content.body.length < 1000) {
            return {
                text: '失败(IP)',
                background: C_FAIL,
            };
        }
        return {
            text: '解锁',
            background: C_UNL,
        };
    } else {
        return {
            text: '失败(' + content.body.slice(content.body.indexOf('expires in ') + 11).replace('and', '').replace('seconds', 's').replace('minutes', 'm').replace('hours', 'h').replace('days', 'd').replace(/ /g, '') + ')',
            background: C_FAIL,
        };
    }
}
