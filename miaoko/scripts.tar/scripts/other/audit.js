const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';
const C_CN = '250,213,149';

function get_requests(url) {
    const Content = fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        },
        noRedir: false,
        retry: 5,
        timeout: 10000,
    });
    if (!Content) {
        return false
    }
    return true
}

function handler() {
    const content = fetch('https://www.youtube.com/', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    var base = 1;
    if (get_requests('https://www.qbittorrent.org/') == false) {
        base *= 2
    }
    if (get_requests('https://www.xunlei.com/') == false) {
        base *= 3
    }
    if (get_requests('https://grr.la/mail/pokemail.net') == false) {
        base *= 5
    }
    if (get_requests('https://www.360.cn/') == false) {
        base *= 7
    }
    if (get_requests('https://www.epochtimes.com/') == false) {
        base *= 11
    }
    if (get_requests('https://tw.gashpoint.com/') == false) {
        base *= 13
    }
    if (get_requests('https://www.mycard520.com.tw/') == false) {
        base *= 17
    }
    if (get_requests('https://www.president.gov.tw/') == false) {
        base *= 19
    }
    if (get_requests('https://www.gov.kr/') == false) {
        base *= 23
    }
    if (get_requests('https://www.cctv.cn/') == false) {
        base *= 29
    }
    if (base == 1) {
        return {
            text: '无审计',
            background: C_FAIL,
        };
    }
    else if (base == 6469693230) {
        return {
            text: '完全审计',
            background: C_UNL,
        }; 
    }
    else {
        return {
            text: '审计(Level ' + String(base) + ')',
            background: C_CN,
        };
    }
}
