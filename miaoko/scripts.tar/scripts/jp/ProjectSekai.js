/*
 # @Author: Telegram @kogeki_bot @FullTclash
 # @python: @kogeki_bot
 # @javascript二改：@FullTclash
 # @Date: 2023-02-18
 # @Telegram: https://t.me/kogeki_bot
 # @LastEditTime: 2023-03-05 20:54:40
 # Copyright © 2023 by kogeki_bot, All Rights Reserved. 
 # 允许重写、转载、重新分发此脚本乃至商用。要求保留此原作者信息。
*/

const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_WAIT = '255,213,128';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://game-version.sekai.colorfulpalette.org', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36',
            'Accept-Language': 'en',
        },
        noRedir: true,
        retry: 3,
        timeout: 5000,
    });

    if (!content || !content.body) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.statusCode == 403) {
        if (content.body.indexOf("AccessDenied") == -1){
            return {
                text: '失败',
                background: C_FAIL,
            };
        } else{
            return {
                text: '解锁',
                background: C_UNL,
            };
        }

    } else {
        return {
            text: '失败',
            background: C_FAIL,
        };
    }
}