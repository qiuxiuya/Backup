const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';
const C_WAIT = '255,213,128';

function handler() {
    const content = fetch('https://api.beacon.dmm.com/v1/streaming/start', {
        method: 'POST',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
        },
        body: '{"player_name":"dmmtv_browser","player_version":"0.0.0","content_type_detail":"VOD_SVOD","content_id":"11uvjcm4fw2wdu7drtd1epnvz","purchase_product_id":null}',
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });

    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.body.indexOf('FOREIGN') > 0) {
        return {
            text: '失败',
            background: C_FAIL,
        };
    } else if (content.body.indexOf('UNAUTHORIZED') > 0) {
        return {
            text: '解锁',
            background: C_UNL,
        };
    } else {
        return {
            text: '待解锁',
            background: C_WAIT,
        };
    }
}