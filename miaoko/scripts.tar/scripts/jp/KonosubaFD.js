const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

const url = 'https://api.konosubafd.jp/api/masterlist';

function handler() {
  const content = fetch(url, {
    method: 'POST',
    headers: {
      'User-Agent': 'pj0007/212 CFNetwork/1240.0.4 Darwin/20.6.0',
    },
    body: null,
    referrerPolicy: 'strict-origin-when-cross-origin',
    noRedir: false,
    retry: 3,
    timeout: 5000,
  });

  if (!content) {
    return {
      text: 'N/A',
      background: C_NA,
    };
  } else if (content.statusCode == 200 || content.statusCode == 302) {
    return {
      text: '解锁',
      background: C_UNL,
    };
  } else {
    return {
      text: '失败',
      background: C_FAIL,
    };
  }
}
