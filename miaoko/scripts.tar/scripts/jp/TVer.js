const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://platform-api.tver.jp/v2/api/platform_users/browser/create', {
        method: 'POST',
        headers: {
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://s.tver.jp',
            'referer': 'https://s.tver.jp/',
            'accept-language': 'en-US,en;q=0.9',
            'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
        },
        body: 'device_type=pc',
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    const content2 = fetch('https://platform-api.tver.jp/service/api/v1/callHome?platform_uid=' + safeParse(content.body).result.platform_uid + '&platform_token=' + safeParse(content.body).result.platform_token + '&require_data=mylist%2Cresume%2Clater', {
        headers: {
            'origin': 'https://tver.jp',
            'referer': 'https://tver.jp/',
            'accept-language': 'en-US,en;q=0.9',
            'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'x-tver-platform-type': 'web',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content2) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    let episodeId = 'ep7oj5bhry';
    for (let component of safeParse(content2.body).result.components) {
        if (component.componentID == 'newer.') {
            episodeId = component.contents[0].content.id;
            break;
        }
    }
    const content3 = fetch(`https://statics.tver.jp/content/episode/${episodeId}.json`, {
        headers: {
            'origin': 'https://tver.jp',
            'referer': 'https://tver.jp/',
            'accept-language': 'en-US,en;q=0.9',
            'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content3) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    const accountID = safeParse(content3.body).video.accountID;
    const playerID = safeParse(content3.body).video.playerID;
    const videoID = safeParse(content3.body).video.videoID;
    const videoRefID = safeParse(content3.body).video.videoRefID;
    const content4 = fetch(`https://players.brightcove.net/${accountID}/${playerID}_default/index.min.js`, {
        headers: {
            'Referer': 'https://tver.jp/',
            'Sec-Fetch-Dest': 'script',
            'Sec-Fetch-Mode': 'no-cors',
            'Sec-Fetch-Site': 'cross-site',
            'accept-language': 'en-US,en;q=0.9',
            'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content4) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    let content5 = {}
    const policyKey = content4.body.match(/policyKey:"([^"]+)"/)[1];
    if (!videoRefID) {
        const deliveryConfigId = content4.body.match(/deliveryConfigId:"([^"]+)"/)[1];
        content5 = fetch(`https://edge.api.brightcove.com/playback/v1/accounts/${accountID}/videos/${videoID}?config_id=${deliveryConfigId}`, {
            headers: {
                'accept': `application/json;pk=${policyKey}`,
                'origin': 'https://tver.jp',
                'referer': 'https://tver.jp/',
                'accept-language': 'en-US,en;q=0.9',
                'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'cross-site',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
            },
            noRedir: false,
            retry: 3,
            timeout: 5000,
        });
    } else {
        content5 = fetch(`https://edge.api.brightcove.com/playback/v1/accounts/${accountID}/videos/ref%3A${videoRefID}`, {
            headers: {
                'accept': `application/json;pk=${policyKey}`,
                'origin': 'https://tver.jp',
                'referer': 'https://tver.jp/',
                'accept-language': 'en-US,en;q=0.9',
                'sec-ch-ua': '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'cross-site',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
            },
            noRedir: false,
            retry: 3,
            timeout: 5000,
        });
    }
    if (!content5) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content5.body.indexOf('CLIENT_GEO') > 0) {
        return {
            text: '失败',
            background: C_FAIL,
        };
    } else {
        return {
            text: '解锁',
            background: C_UNL,
        };
    }
}
