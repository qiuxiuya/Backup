const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';
const C_WAIT = '255,213,128';
intl_link = "https://api.bilibili.tv/intl/gateway/v2/ogv/view/app/season?season_id=1006275&s_locale=zh_SG&mobi_app=bstar_a&build=1080003"      //解锁判断
spy_family_link = "https://api.bilibili.tv/intl/gateway/v2/ogv/view/app/season?season_id=1048837&s_locale=zh_SG&mobi_app=bstar_a&build=1080003"      //仅限国创
thailand_link = "https://api.bilibili.tv/intl/gateway/v2/ogv/view/app/season?season_id=1057120&s_locale=zh_SG&mobi_app=bstar_a&build=1080003"        //泰国
vietnam_link = "https://api.bilibili.tv/intl/gateway/v2/ogv/view/app/season?season_id=1057175&s_locale=zh_SG&mobi_app=bstar_a&build=1080003"         //越南
indonesia_link = "https://api.bilibili.tv/intl/gateway/v2/ogv/view/app/season?season_id=1057318&s_locale=zh_SG&mobi_app=bstar_a&build=1080003"       //印尼

function handler() {
    intl = get_requests(intl_link)
    if (intl === -1) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (intl === 1) {
        if (get_requests(spy_family_link)) {
            if (get_requests(thailand_link)) {
                return {
                    text: '解锁(泰国)',
                    background: C_UNL,
                };
            } else if (get_requests(vietnam_link)) {
                return {
                    text: '解锁(越南)',
                    background: C_UNL,
                };
            } else if (get_requests(indonesia_link)) {
                return {
                    text: '解锁(印尼)',
                    background: C_UNL,
                };
            } else {
                return {
                    text: '解锁(东南亚)',
                    background: C_UNL,
                };
            }
        } else {
            return {
                text: '解锁(仅限国区)',
                background: C_UNL,
            };
        }
    } else {
        return {
            text: '失败',
            background: C_FAIL,
        };
    }
}

function get_requests(url) {
    const Content = fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!Content) {
        return -1
    } else {
        const JsonData = safeParse(get(Content, "body"));
        if (get(JsonData, "code") == 0) {
            const result = get(JsonData, "result", {});
            if (get(result, "limit") == null) {
                return 1
            } else {
                return 0
            }
        } else {
            return 0
        }
    }

}