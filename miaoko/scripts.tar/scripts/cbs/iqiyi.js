/*
 # @Author: Telegram @FullTclash
 # @Date: 2023-03-06
 # @Telegram: https://t.me/FullTclash
 # Copyright © 2023 by FullTclash, All Rights Reserved. 
 # 允许重写、转载、重新分发此脚本乃至商用。要求保留此原作者信息。
*/

const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
  const content = fetch('https://www.iq.com/?lang=en_us', {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
    },
    noRedir: false,
    retry: 3,
    timeout: 5000,
  });

  if (!content) {
    return {
      text: 'N/A',
      background: C_NA,
    };
  } else if (content.statusCode == 200) {
    let info = content.body
    var index = info.indexOf("intlPageInfo.pbInfos = {");
    if (index > 0) {
        var sinfo = info.substring(index, index + 110);
        var index2 = sinfo.indexOf("mod:");
        var sinfo2 = sinfo.substring(index2 + 98);
        var r = sinfo2.split('"');
        var region = r[0] ? r[0] : "NOT FOUND";
        if (region == "ntw") {
            region = "TW";
        } else if (region == "intl") {
            region = "国际";
        } else {
            region = region.toUpperCase();
        }
        return {
            text: `解锁(${region})`,
            background: C_UNL,
        };
    } else {
        return {
            text: '未知',
            background: C_UNK,
        };
    }
  } else {
    return {
      text: '未知',
      background: C_UNK,
    };
  }
}
