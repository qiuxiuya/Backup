const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_WAIT = '255,213,128';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://www.youtube.com/premium', {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36",
            "upgrade-insecure-requests": "1",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "Accept-Language": "en",
        },
        cookies: {
            'YSC': 'BiCUU3-5Gdk',
            'CONSENT': 'YES+cb.20220301-11-p0.en+FX+700',
            'GPS': '1',
            'VISITOR_INFO1_LIVE': '4VwPMkB7W5A',
            'PREF': 'tz=Asia.Shanghai',
            '_gcl_au': '1.1.1809531354.1646633279',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });

    if (!content || !content.body) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.body.indexOf("www.google.cn") > -1) {
        return {
            text: '送中(CN)',
            background: C_WAIT,
        };
    } else if (content.body.indexOf('premium is not available in your country') >= 0) {
        return {
            text: '失败',
            background: C_FAIL,
        };
    } /*else if (content.body.indexOf('manageSubscriptionButton') <= 0) {
        return {
            text: '失败2',
            background: C_FAIL,
        };
    } */else if (content.statusCode == 200) {
        const regex = /"countryCode":"(.*?)"/;
        const location = (regex.exec(content.body) || [])[1] || 'us';
        return {
            text: '解锁(' + location.toLocaleUpperCase() + ')',
            background: C_UNL,
        };
    } else {
        return {
            text: '未知',
            background: C_UNK,
        };
    }
}
