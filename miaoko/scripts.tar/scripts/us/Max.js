const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://www.max.com/', {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    
    const countryRegex = /"url":"\/([a-z]{2})\/[a-z]{2}"/g;
    const countries = get(content, "body", '"url":"/us/es"').match(countryRegex);
    const uniqueCountries = new Set(countries.map(match => match.split('/')[1].toUpperCase()));
    const countryList = [...uniqueCountries].join(' ') + ' US';
    const region = get(get(content, "cookies", [{}])[0], "Value", "")
    if (countryList.includes(region)) {
        return {
            text: '解锁(' + region + ')',
            background: C_UNL,
        };
    }
    else {
        return {
            text: '失败(' + region + ')',
            background: C_FAIL,
        };
    }
}
