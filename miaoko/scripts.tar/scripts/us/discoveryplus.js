const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

const url =
  'https://us1-prod-direct.discoveryplus.com/token?deviceId=d1a4a5d25212400d1e6985984604d740&realm=go&shortlived=true';

const url2 = 'https://us1-prod-direct.discoveryplus.com/users/me';

function handler() {
  const content = fetch(url, {
    headers: {
      'User-Agent':
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
    },
    noRedir: false,
    retry: 3,
    timeout: 5000,
  });
  
  if (!content) {
    return {
      text: 'N/A',
      background: C_NA,
    };
  } else if (content.statusCode == 200) {
    const res = JSON.parse(content.body);
    const token = res.data.attributes.token;
    const content2 = fetch(url2, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
        cookie: 'st=' + token,
      },
      noRedir: false,
      retry: 3,
      timeout: 5000,
    });

    if (!content2) {
      return {
        text: 'N/A',
        background: C_NA,
      };
    } else if (content2.statusCode == 200) {
      const res2 = JSON.parse(content2.body);

      const currentLocationTerritory =
        res2.data.attributes.currentLocationTerritory;

      const flag = currentLocationTerritory === 'us';

      if (flag) {
        return {
          text: '解锁(US)',
          background: C_UNL,
        };
      } else {
        return {
          text: '失败(' + currentLocationTerritory.toUpperCase() + ')',
          background: C_FAIL,
        };
      }
    } else {
      return {
        text: '未知',
        background: C_UNK,
      };
    }
  } else {
    return {
      text: '未知',
      background: C_UNK,
    };
  }
}
