const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://api.epix.com/v2/sessions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            "device": {
                "guid": "e2add88e-2d92-4392-9724-326c2336013b",
                "format": "console",
                "os": "web",
                "app_version": "1.0.2",
                "model": "browser",
                "manufacturer": "google"
            },
            "apikey": "53e208a9bbaee479903f43b39d7301f7",
            "oauth": {
                "token": null
            }
        }),
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.body.indexOf('error code') > 0) {
        return {
            text: '失败',
            background: C_FAIL,
        };
    } else {
        const content2 = fetch('https://api.epix.com/graphql', {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'X-Session-Token': JSON.parse(content.body).device_session.session_token || ""
            },
            body: JSON.stringify({
                "operationName": "PlayFlow",
                "variables": {
                    "id": "bW92aWU7MjExNDc=",
                    "supportedActions": [
                        "open_url",
                        "show_notice",
                        "start_billing",
                        "play_content",
                        "log_in",
                        "noop",
                        "confirm_provider",
                        "unlinked_provider"
                    ],
                    "streamTypes": [
                        {
                            "encryptionScheme": "CBCS",
                            "packagingSystem": "DASH"
                        },
                        {
                            "encryptionScheme": "CENC",
                            "packagingSystem": "DASH"
                        },
                        {
                            "encryptionScheme": "NONE",
                            "packagingSystem": "HLS"
                        }, 
                        {
                            "encryptionScheme": "SAMPLE_AES",
                            "packagingSystem": "HLS"
                        }
                    ]
                },
                "query": "fragment ShowNotice on ShowNotice {\n  type\n  actions {\n    continuationContext\n    text\n    __typename\n  }\n  description\n  title\n  __typename\n}\n\nfragment OpenUrl on OpenUrl {\n  type\n  url\n  __typename\n}\n\nfragment Content on Content {\n  title\n  __typename\n}\n\nfragment Movie on Movie {\n  id\n  shortName\n  __typename\n}\n\nfragment Episode on Episode {\n  id\n  series {\n    shortName\n    __typename\n  }\n  seasonNumber\n  number\n  __typename\n}\n\nfragment Preroll on Preroll {\n  id\n  __typename\n}\n\nfragment ContentUnion on ContentUnion {\n  ...Content\n  ...Movie\n  ...Episode\n  ...Preroll\n  __typename\n}\n\nfragment PlayContent on PlayContent {\n  type\n  continuationContext\n  heartbeatToken\n  currentItem {\n    content {\n      ...ContentUnion\n      __typename\n    }\n    __typename\n  }\n  nextItem {\n    content {\n      ...ContentUnion\n      __typename\n    }\n    showNotice {\n      ...ShowNotice\n      __typename\n    }\n    showNoticeAt\n    __typename\n  }\n  amazonPlaybackData {\n    pid\n    playbackToken\n    materialType\n    __typename\n  }\n  playheadPosition\n  vizbeeStreamInfo {\n    customStreamInfo\n    __typename\n  }\n  closedCaptions {\n    ttml {\n      location\n      __typename\n    }\n    vtt {\n      location\n      __typename\n    }\n    xml {\n      location\n      __typename\n    }\n    __typename\n  }\n  hints {\n    duration\n    seekAllowed\n    trackingEnabled\n    trackingId\n    __typename\n  }\n  streams(types: $streamTypes) {\n    playlistUrl\n    closedCaptionsEmbedded\n    packagingSystem\n    encryptionScheme\n    videoQuality {\n      height\n      width\n      __typename\n    }\n    widevine {\n      authenticationToken\n      licenseServerUrl\n      __typename\n    }\n    playready {\n      authenticationToken\n      licenseServerUrl\n      __typename\n    }\n    fairplay {\n      authenticationToken\n      certificateUrl\n      licenseServerUrl\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment StartBilling on StartBilling {\n  type\n  __typename\n}\n\nfragment LogIn on LogIn {\n  type\n  __typename\n}\n\nfragment Noop on Noop {\n  type\n  __typename\n}\n\nfragment PreviewContent on PreviewContent {\n  type\n  title\n  description\n  stream {\n    sources {\n      hls {\n        location\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n  __typename\n}\n\nfragment ConfirmProvider on ConfirmProvider {\n  type\n  __typename\n}\n\nfragment UnlinkedProvider on UnlinkedProvider {\n  type\n  __typename\n}\n\nquery PlayFlow($id: String\u0021, $supportedActions: [PlayFlowActionEnum\u0021]\u0021, $context: String, $behavior: BehaviorEnum = DEFAULT, $streamTypes: [StreamDefinition\u0021]) {\n  playFlow(\n    id: $id\n    supportedActions: $supportedActions\n    context: $context\n    behavior: $behavior\n  ) {\n    ...ShowNotice\n    ...OpenUrl\n    ...PlayContent\n    ...StartBilling\n    ...LogIn\n    ...Noop\n    ...PreviewContent\n    ...ConfirmProvider\n    ...UnlinkedProvider\n    __typename\n  }\n}"
            }),
            noRedir: false,
            retry: 3,
            timeout: 5000,
        });
        if (!content2) {
            return {
                text: 'N/A',
                background: C_NA,
            };
        } else if (content2.body.indexOf('is only available in the United States') > 0) {
            return {
                text: '失败',
                background: C_FAIL,
            };
        } else {
            return {
                text: '解锁',
                background: C_UNL,
            };
        }

    }
}
