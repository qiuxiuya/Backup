const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://www.sling.com/', {
        headers: {
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; ALP-AL00 Build/HUAWEIALP-AL00)',
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.statusCode == 200) {
        if (content.body.indexOf('INSIDE') > 0) {
            return {
                text: '失败',
                background: C_FAIL,
            };
        }
        else {
            return {
                text: '解锁',
                background: C_UNL,
            };
        }

    } else {
        return {
            text: '未知',
            background: C_UNK,
        };
    }
}
