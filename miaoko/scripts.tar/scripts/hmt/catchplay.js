const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://sunapi.catchplay.com/geo', {
        headers: {
            'authorization': 'Basic NTQ3MzM0NDgtYTU3Yi00MjU2LWE4MTEtMzdlYzNkNjJmM2E0Ok90QzR3elJRR2hLQ01sSDc2VEoy'
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content.statusCode == 200) {
        if (JSON.parse(content.body).code === '0') {
            return {
                text: '解锁(' + JSON.parse(content.body).data.isoCode + ')',
                background: C_UNL,
            };
        } else {
            return {
                text: '失败',
                background: C_FAIL,
            };
        }
    } else {
        return {
            text: '失败',
            background: C_FAIL,
        };
    }
}
