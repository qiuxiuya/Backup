const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

const url = 'https://www.linetv.tw/api/part/11829/eps/1/part?appId=062097f1b1f34e11e7f82aag22000aee&device=desktop_web&instanceId=54dc2cef-c765-449b-be4c-92e21068d327&sessionId=8a6d0e93-5ae5-432c-baf2-47ef76db9200&chocomemberId=&productType=VOD&os=&version=10.29.0';

function handler() {
  const content = fetch(url, {
    headers: {
      'User-Agent':
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36',
    },
    noRedir: false,
    retry: 3,
    timeout: 5000,
  });

  if (!content) {
    return {
      text: 'N/A',
      background: C_NA,
    };
  } else{
    if (content.body.indexOf("dramaInfo") == -1) {
      return {
        text: '失败',
        background: C_FAIL,
      };
    } else {
     return {
        text: '解锁',
        background: C_UNL,
      };
    }
  } 
}
