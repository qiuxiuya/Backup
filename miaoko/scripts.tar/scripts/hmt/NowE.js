const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

function handler() {
    const content = fetch('https://webtvapi.nowe.com/16/1/getVodURL', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            contentId: '202105121370235',
            contentType: 'Vod',
            pin: '',
            deviceId: 'W-60b8d30a-9294-d251-617b-6oagagn3',
            deviceType: 'WEB'
        }),
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });

    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (JSON.parse(content.body).responseCode === "SUCCESS" || JSON.parse(content.body).responseCode === "PRODUCT_INFORMATION_INCOMPLETE") {
        return {
            text: '解锁',
            background: C_UNL,
        };
    } else {
        return {
            text: '失败',
            background: C_FAIL,
        };
    }
}