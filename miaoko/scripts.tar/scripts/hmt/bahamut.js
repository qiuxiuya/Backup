const C_NA = '142,140,142';
const C_UNL = '186,230,126';
const C_FAIL = '239,107,115';
const C_UNK = '92,207,230';

const UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
const UA_SEC_CH_UA = '"Google Chrome";v="125", "Chromium";v="125", "Not.A/Brand";v="24"'
function handler() {
    const content = fetch('https://ani.gamer.com.tw/ajax/getdeviceid.php', {
        headers: {
            'User-Agent': UA_BROWSER,
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    }
    const content2 = fetch('https://ani.gamer.com.tw/ajax/token.php?adID=89422&sn=37783&device=' + get(safeParse(get(content, "body")), "deviceid", ""), {
        headers: {
            'Cookie': String(content.cookies[2]) + '; ' + String(content.cookies[1]),
            'User-Agent': UA_BROWSER,
        },
        noRedir: false,
        retry: 3,
        timeout: 5000,
    });
    if (!content2) {
        return {
            text: 'N/A',
            background: C_NA,
        };
    } else if (content2.body.indexOf('animeSn') != -1) {
        const content3 = fetch('https://ani.gamer.com.tw/', {
            headers: {
                'User-Agent': UA_BROWSER,
                'Cookie': String(content.cookies[2]) + '; ' + String(content.cookies[1]),
                'accept': '*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'zh-CN,zh;q=0.9',
                'sec-ch-ua': UA_SEC_CH_UA,
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-model': '""',
                'sec-ch-ua-platform': 'Windows',
                'sec-ch-ua-platform-version': '15.0.0',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1'
            },
            noRedir: false,
            retry: 3,
            timeout: 5000,
        });
        if (!content3) {
            return {
                text: 'N/A',
                background: C_NA,
            };
        }
        return {
            text: '解锁(' + content3.body.match(/data-geo="([^"]+)"/)[1] + ')',
            background: C_UNL,
        };
    } else {
        return {
            text: '失败',
            background: C_FAIL,
        };
    }
}